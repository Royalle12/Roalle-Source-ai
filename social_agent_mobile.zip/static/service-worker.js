// Royalle Source - Executive Command Center Service Worker
const CACHE_NAME = 'royalle-v1';
const ASSETS = [
  '/',
  '/static/icon.png',
  '/static/manifest.json'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(ASSETS))
  );
});

self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request).then((response) => response || fetch(event.request))
  );
});
